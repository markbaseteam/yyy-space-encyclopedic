---
abbrlink: "20220504165045"
aliases: ["Responsibility for Safety"]
dg-publish: true
created: 2022-05-04 16:50
updated: 2022-05-26 16:35
title: Responsibility for Safety
---

# Responsibility for Safety

- Workers/ Operators
  - 制造危险
  - 在危险情况下工作
  - 被危险影响了
- 管理层
  - 分配（、制造）工作
  - 对于工作的全面管理和了解
  - 法律上的责任

---

## 工程师

1. 是管理的一员
2. 对工作有足够的知识和了解
3. 在工作中有一定影响力（话语权）

因此 -> 工程师有责任去保证他人的安全：手下、群众

### 在安全方面的作用

1. 设计时对安全的考量
2. 计划、监督、管理 所有 人员和工作
