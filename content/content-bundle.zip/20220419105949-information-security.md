---
abbrlink: "20220419105949"
aliases: ["Information Security", "InfoSec"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:59:49
updated: 2022-05-26 16:33
title: Information Security
---

# Information Security

> [!word] Information Security
> The process of protecting a company's information assets from all types of risk.
