---
abbrlink: "20220419102632"
aliases: ["Computer Forensics"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:26:32
updated: 2022-05-26 16:35
title: Computer Forensics
---

# Computer Forensics

> [!word] Computer Forensics
>
> - Extraction of digital evidence from a computer
> - Allows the companies to understand
>   - how a hack happened
>   - what events took place during the hack
>   - if there is any evidence that those systems are still infected

> [!note]
> Computer forensics is not a perfect science, there are ways for someone to delete evidence from a computer that can stall or prevent forensic work.
> However, for the most part it does find a lot of useful information and it is an important part of recovering from a major cyberattack.
