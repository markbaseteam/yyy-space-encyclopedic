---
abbrlink: "20220419141010"
aliases: ["Common Types of Disasters"]
tags:
dg-publish: true
created: Tue 2022-04-19 14:10:10
updated: 2022-05-26 16:33
title: Common Types of Disasters
---

# Common Types of Disasters

1. Application failure
2. Communication failure
3. Data center disaster
4. Building disaster
5. Campus disaster
6. Citywide disaster
7. Regional disaster
8. National disaster
9. Multinational disaster
10. Cloud infrastructure failure
