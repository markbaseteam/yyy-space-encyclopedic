---
abbrlink: "20220419102033"
aliases: ["Cybersecurity Regulatory Compliance"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:20:33
updated: 2022-05-26 16:35
title: Cybersecurity Regulatory Compliance
---

# Cybersecurity Regulatory Compliance

> [!word] Cybersecurity Regulatory Compliance
> Work with companies to make sure they meet all the requirements that their regulators mandate for them.

> [!example]
> HIPAA is a regulation that affects companies in the healthcare industry.
> There can also be regulations that are assigned by the government to all companies within the nation.
