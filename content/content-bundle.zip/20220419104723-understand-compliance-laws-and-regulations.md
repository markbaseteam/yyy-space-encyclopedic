---
abbrlink: "20220419104723"
aliases: ["Understand Compliance Laws and Regulations"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:47:23
updated: 2022-05-26 16:35
title: Understand Compliance Laws and Regulations
---

# Understand Compliance Laws and Regulations

> [!word] Understand Compliance Laws and Regulations
> Rules by governments and regulators to mandate that companies have certain levels of security measures in place to protect consumer information.

> [!examples]
> CCPA
> PIPEDA
> SOX
> GDPR
> PCI-DSS
