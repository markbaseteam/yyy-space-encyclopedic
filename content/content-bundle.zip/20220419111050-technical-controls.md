---
abbrlink: "20220419111050"
aliases: ["Technical Controls"]
tags:
dg-publish: true
created: Tue 2022-04-19 11:10:50
updated: 2022-06-21 16:11
title: Technical Controls
---

# Technical Controls

> [!word] Technical Controls #control-category 
> Makes use of **technology** to **reduce vulnerabilities**
> Technologies include (not ltd. to): 
> - Hardware
> - Software 
> - Firmware
> - Firewalls 
> - Security Groups

## Examples of Technical Controls 【技术规范例子】

- [[20220602130052-encryption|Encryption]] 
	- 数据 [[20220602125634-confidentiality|机密性]]
- [[20220421233306-antivirus|Antivirus]]
	- Protect Against [[20220516095203-malware|Malware]] 
- IDS and IPS 
	- Monitor a network or host for intrusions 
	- Provide ongoing protections 
- Firewalls 
	- Restrict network in and out 
- Least Priviledge 
