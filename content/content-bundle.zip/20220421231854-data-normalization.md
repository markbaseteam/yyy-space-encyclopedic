---
abbrlink: "20220421231854"
aliases: ["Data Normalization"]
tags:
dg-publish: true
created: Thu 2022-04-21 23:18:54
updated: 2022-05-26 16:35
title: Data Normalization
---

# Data Normalization

> [!word] Data Normalization
> Taking different events from several places and putting them into common categories so analysis can be correctly made.

> [!example]
>
> 1.  Converting all currencies to a common one
> 2.  Converting all timezones into UTC
