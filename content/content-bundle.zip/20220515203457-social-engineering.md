---
abbrlink: "20220515203457"
aliases: ["Social Engineering"]
dg-publish: true
created: 2022-05-15 20:34
updated: 2022-05-26 16:35
title: Social Engineering
---

# Social Engineering

> [!word] Social Engineering
> 一直在变，你永远不会知道他们下一次会用什么

- 可以包含很多人（甚至很多机构）去完成一个攻击
- 可能通过电话或电子渠道
  - Phone calls from aggressive "customers"
  - Emailed funeral notifications of a friend or associate
  - take advantage of your emotions and make you click into something
