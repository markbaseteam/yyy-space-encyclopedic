---
title: Web Browser and Cookies
created: Sat 19-03-2022 07:47
updated: 2022-05-26 16:35
tags:
aliases: [Web Browser and Cookies]
abbrlink: "20220319074755"
dg-publish: true
---

# Web Browser and Cookies

## Web Browser

- **Browser history** and **IP address** can show location.

## Cookies

[[20220319074837-cookies|20220319074837 Cookies]]
