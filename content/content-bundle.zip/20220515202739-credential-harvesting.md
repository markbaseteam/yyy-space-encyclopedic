---
abbrlink: "20220515202739"
aliases: ["Credential Harvesting", "Password Harvesting"]
dg-publish: true
created: 2022-05-15 20:27
updated: 2022-05-31 17:39
title: Credential Harvesting
cards-deck: Encyclopedia
---

# Credential Harvesting

> [!word] Credential Harvesting #attack
> 收集你电脑里储存的用户名和[[20220319080333-passwords|密码]]
>
> - 用户大几率都不会知道
<!--ID: 1653993498035-->


- 来源（尝试取得所有 sources）
  - Chrome
  - Firefox
  - Outlook
  - Windows Credential Manager
  - …

## Credential Harvesting 步骤 #card

1. 傻子收到带有 Microsoft Word 文件的 email
2. 傻子打开文件
3. Macro 启动
4. Macro 下载 Credential-harvesting malware
5. 其他就很容易理解了
6. 最后自动把所有资料发給坏人
