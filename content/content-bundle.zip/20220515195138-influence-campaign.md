---
abbrlink: "20220515195138"
aliases: ["Influence Campaign"]
dg-publish: true
created: 2022-05-15 19:51
updated: 2022-05-26 16:35
title: Influence Campaign
---

# Influence Campaign

> [!word] Influence Campaign
> 用不同渠道去尝试改变公众的观点（sway public opinion on political and social issues ）

- [[20220606151734-state-actors|Nation-state actors]]
  - Divide, distract, and persuade
- Advertising is an option
  - Buy a voice for your opinion
- Enabled through social media
  - Creating, sharing, liking
  - Amplification of the opinion

> [!idea]
> 就像 美国 结合其他国家的 反对派 去洗脑

## 程序

1. 注册虚假用户
2. 制作内容
3. 发布内容
4. 矿大影响力
5. 真正用户看到并转发
6. 媒体发现并转播
