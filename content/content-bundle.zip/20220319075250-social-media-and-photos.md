---
title: Social Media and Photos
created: Sat 19-03-2022 07:52
updated: 2022-05-26 16:35
tags:
aliases: [Social Media and Photos]
abbrlink: "20220319075250"
dg-publish: true
---

# Social Media and Photos

## Privacy

Social Media timelines and check-ins can reveal your current or past locations.

Metadata, such as location, date, and time, can be stored in photos.
