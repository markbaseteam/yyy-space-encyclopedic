---
title: Desktop Computers
created: Fri 18-03-2022 22:41
updated: 2022-05-26 16:35
course: 820-CLOUD COMPUTING
tags:
aliases: [Desktop Computers]
abbrlink: "20220318224116"
dg-publish: true
---

# Desktop Computers

## [[20220318223248-cloud-computing|Cloud Computing]]

- [[20220318223917-end-user|End user]] can access the [[20220318223248-cloud-computing|cloud computing]] system apps and data from any computer with internet connection.
