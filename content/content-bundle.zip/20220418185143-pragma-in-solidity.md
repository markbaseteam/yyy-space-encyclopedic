---
abbrlink: "20220418185143"
aliases: ["Pragma in Solidity", "Pragma"]
tags:
dg-publish: true
created: Thu 1970-01-01 08:00:00
updated: 2022-05-26 16:35
title: Pragma in Solidity
---

# Pragma in Solidity

A pragma is an indicator of the acceptable solidity versions. Because the language is still in its early stages, it has to be included in case there are future breaking changes that modifies the stuff used in a code.

```java
pragma solidity >=0.5.0 <0.6.0;
```

Praga should be the first line in a solidity contract, so it should come before [[20220415192511-contract-in-solidity.md|the contract block]].
