---
abbrlink: "20220419102224"
aliases: ["Incident Responder"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:22:24
updated: 2022-05-26 16:33
title: Incident Responder
---

# Incident Responder

> [!word] Incident Responder
> Respond to a [[20220419102338-security-incident|security incident]] by
>
> - containing the situation so the hack cannot spread to other parts of the company
> - removing any malware
> - restoring any information or services that were lost because of the hack
