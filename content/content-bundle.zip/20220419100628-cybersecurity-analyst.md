---
abbrlink: "20220419100628"
aliases: ["Cybersecurity Analyst"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:06:28
updated: 2022-05-26 16:33
title: Cybersecurity Analyst
---

# Cybersecurity Analyst

> [!word] Cybersecurity Analyst
> Look at a company's asset and give recommendations on how to prevent them from getting hacked. Basically strategizing and planning out how the company is going to protect their assets.
