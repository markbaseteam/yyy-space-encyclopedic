---
abbrlink: "20220419102952"
aliases: ["Skills required in InfoSec"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:29:52
updated: 2022-05-26 16:35
title: Skills Required in InfoSec
---

# Skills Required in InfoSec

- Understand networking and network technologies
- Programming
  - Python
  - PHP
  - Java
  - C
  - C++
  - Javascript
- [[20220419104910-responding-to-an-incident|Responding to an Incident]]
- [[20220419104723-understand-compliance-laws-and-regulations|Understand Compliance Laws and Regulations]]
- Loving the command line --> [TryHackMe | Complete Beginner Training](https://tryhackme.com/path/outline/beginner)
- [[20220419105601-understand-how-computer-hacks-happen|Understand how computer hacks happen]]
