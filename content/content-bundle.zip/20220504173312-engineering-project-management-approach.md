---
abbrlink: "20220504173312"
aliases:
  ["Engineering Project Management Approach", "Project Management Approach"]
dg-publish: true
created: 2022-05-04 17:33
updated: 2022-05-26 16:35
title: Engineering Project Management Approach
---

# Engineering Project Management Approach

![](../60-Meta-Attachments/Pasted-image-20220504173331.png)

1. 提前计划（避免或減少災難）
2. 如果有意外，也有完善的應急措施 ([Risk Assessment](20220504182500-risk-assessment.md) and Risk Control)
