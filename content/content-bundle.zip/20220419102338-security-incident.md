---
abbrlink: "20220419102338"
aliases: ["Security Incident"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:23:38
updated: 2022-05-26 16:33
title: Security Incident
---

# Security Incident

> [!word] Security Incident
> Successful cyberattacks against a company.
