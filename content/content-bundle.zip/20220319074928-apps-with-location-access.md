---
title: Apps with Location Access
created: Sat 19-03-2022 07:49
updated: 2022-05-26 16:35
tags:
aliases: [Apps with Location Access]
abbrlink: "20220319074928"
dg-publish: true
---

# Apps with Location Access

Sometimes when downloading or using an app, the app asks for **permission to track location, location history, or other information on your device**.
