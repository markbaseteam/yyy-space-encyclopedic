---
title: Data Storage in Cloud Computing
created: Fri 18-03-2022 22:43
updated: 2022-05-26 16:35
aliases: [Data Storage in Cloud Computing]
abbrlink: "20220318224302"
dg-publish: true
---

# Data Storage in Cloud Computing

- The multiple server sites have the ability to **connect, store, and analyse** any amount of data from anywhere.

> [!example]
> AWS has a global infrastructure similar to multiple server sites known as **Availability Zones and Regions**.
