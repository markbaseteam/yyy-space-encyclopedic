---
abbrlink: "20220318223708"
title: Virtual Desktop & Software Platform
created: Fri 18-03-2022 22:37
updated: 2022-06-02 11:24
course: 820-CLOUD COMPUTING
tags:
aliases:
  - Virtual Desktop & Software Platform
dg-publish: true
---

# Virtual Desktop & Software Platform

Software is hosted online by the cloud computing company. Virtual desktops allow users to access the software from any device.
