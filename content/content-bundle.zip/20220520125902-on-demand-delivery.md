---
abbrlink: "20220520125902"
aliases: ["On demand delivery"]
dg-publish: true
created: 2022-05-20 12:59
updated: 2022-06-02 11:55
title: On Demand Delivery
---

# On Demand Delivery

#cloud-computing

> [!word] On demand delivery
> A cloud provider has the resources you need, when you need them.
