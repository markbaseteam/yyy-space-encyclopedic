---
title: Cloud Computing Model
created: Sat 19-03-2022 10:54
updated: 2022-05-31 18:24
course: 820-CLOUD COMPUTING
tags:
aliases:
  - Cloud Computing Model
  - Infrasture as software
  - 20220319105437
dg-publish: true
---

# Cloud Computing Model

**Infrastructure as software**

## Benefits of Software Solutions

- Flexible
- Change more quickly, easily, and cost-effectively than hardware solutions
- Eliminate the undifferentiated heavy-lifting tasks
- [[20220318222441-benefits-of-cloud-computing|benefits of cloud computing]]
