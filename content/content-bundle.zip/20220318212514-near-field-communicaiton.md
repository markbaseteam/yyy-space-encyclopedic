---
title: Near-field Communication
created: Fri 18-03-2022 21:25
updated: 2022-06-05 16:57
aliases:
  - NFC
  - near-field communication
dg-publish: true
---

# Near-field Communication

> [!word] Near-field Communication [NFC]
> Communication Protocol 
> - Enables communication between devices 
> - Bringing them within 4cm 
> - Two-way wireless communicaiton 
>     - Builds on [[20220605163752-radio-frequency-identification|RFID]], which is mostly one-way 
> - NFC Application 
>     - Commonly used in Payment systems 
>     - Bluetooth also uses NFC to simplify pairing process 
>     - Use mobile device as an authentication factor 
>         - Access token 
>         - Identity Card 
>         - Short range with encryption support  
