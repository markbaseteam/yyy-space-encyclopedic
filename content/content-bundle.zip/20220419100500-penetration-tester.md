---
abbrlink: "20220419100500"
aliases: ["Penetration Tester"]
tags:
dg-publish: true
created: tp.date.now("ddd YYYY-MM-DD HH:mm:ss")
updated: 2022-05-26 16:33
title: Penetration Tester
---

# Penetration Tester

> [!word] Penetration Tester (Professional Computer Hackers)
> Gets hired to hack into a company and give security recommendations.
