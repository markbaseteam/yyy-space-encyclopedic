---
abbrlink: "20220419111148"
aliases: ["Physical Security Measures"]
tags:
dg-publish: true
created: Tue 2022-04-19 11:11:48
updated: 2022-05-31 17:02
title: Physical Security Measures
---

# Physical Security Measures

> [!word] Physical Security Measures
> Include cabinet locks, vaults, biometric [[20220311115526-sensors.md|sensors]], and door locks.
> To prevent unauthorized individuals from physically sneaking into the company.
