---
abbrlink: "20220419110207"
aliases: ["Difference between InfoSec and Cybersecurity"]
tags:
dg-publish: true
created: Tue 2022-04-19 11:02:07
updated: 2022-05-26 16:33
title: Difference Between InfoSec and Cybersecurity
---

# Difference Between InfoSec and Cybersecurity

| InfoSec                                                               | Cybersecurity                                                     |
| --------------------------------------------------------------------- | ----------------------------------------------------------------- |
| Focuses on both digital and physical information assets from breaches | Focuses solely on protecting information assets from cyberattacks |

[[20220419105949-information-security|InfoSec]] is a **superset** of [[20220419110129-cybersecurity|Cybersecurity]].
