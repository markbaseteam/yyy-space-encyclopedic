---
title: Traditional Computing Model
created: Sat 19-03-2022 10:51
updated: 2022-05-31 18:24
tags: []
aliases: [Traditional Computing Model]
abbrlink: "20220319105139"
dg-publish: true
---

# Traditional Computing Model

- Infrastructure as hardware

## Cons of Traditional Model

1. Requires space, staff, physical security, planning, capital expenditure
2. Have a long hardware procurement cycle
3. Require you to provision capacity by guessing theoretical maximum peaks
