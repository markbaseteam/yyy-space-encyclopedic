---
title: Similarities Between AWS and Traditional IT
created: Sat 19-03-2022 20:04
updated: 2022-05-26 17:08
aliases:
  - Similarities between AWS and traditional IT
abbrlink: 20220319200405
dg-publish: true
---

# Similarities Between AWS and Traditional IT

|                      | Traditional, on-premises IT Space | AWS                                           |
| -------------------- | --------------------------------- | --------------------------------------------- |
| Security             | Firewalls, ACLs, Administrators   | Security groups, Network ACLs, IAM            |
| Networking           | Router, Network pipeline, Switch  | Elastic Load Balancing, Amazon VPC            |
| Compute              | On-premises servers               | AMI → Amazon EC2 instances                    |
| Storage and database | DAS, SAN, NAS, RBDMS              | Amazon EBS, Amazon EFS, Amazon S3, Amazon RDS |

![[../60-Meta-Attachments/e6eaa25407d00c363fd5d2370b446c46.png]]
