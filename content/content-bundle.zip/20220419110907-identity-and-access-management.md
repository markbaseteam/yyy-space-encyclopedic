---
abbrlink: "20220419110907"
aliases: ["Identity and Access Management", "IAM"]
tags:
dg-publish: true
created: Tue 2022-04-19 11:09:07
updated: 2022-05-26 16:33
title: Identity and Access Management
---

# Identity and Access Management

> [!word] Identity and Access Management
> The practice of ensuring that only the correct individuals are given access to resources.

IAM follows the [[20220318212854-least-privilege|least privilege model]].
