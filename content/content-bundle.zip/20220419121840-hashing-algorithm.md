---
abbrlink: "20220419121840"
aliases: ["Hashing Algorithm", "Hashing"]
tags:
dg-publish: true
created: Tue 2022-04-19 12:18:40
updated: 2022-06-02 18:52
title: Hashing Algorithm
---

# Hashing Algorithm

> [!word] Hashing Algorithm
> Accepts any input and generate a unique fixed length value called a [[20220419121809-hash|hash]]. With any single character or bit changed within the initial information, the [[20220419121809-hash|hash]] will also change.

- Examples of hashing Algorithms
  - MD5
  - SHA
