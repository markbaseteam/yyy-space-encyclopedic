---
abbrlink: "20220419102510"
aliases: ["Crises Communication"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:25:10
updated: 2022-05-26 16:33
title: Crises Communication
---

# Crises Communication

> [!word] Crises Communication
> Deal with the communication aspect of cybersecurity.
>
> - Report to regulatory bodies in a company's area and industry when a data breach occurs
> - Communicate with all the consumers that were affected
