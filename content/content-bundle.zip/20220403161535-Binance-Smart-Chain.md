---
abbrlink: "20220403161535"
aliases: ["Binance Smart Chain", "BSC"]
tags:
created: Sun 2022-04-03 16:15:35
updated: 2022-05-26 17:04
dg-publish: true
title: Binance Smart Chain
---

# Binance Smart Chain

## Negatives

- Not [[20220331193536 Decentralize.md|Decentralized]]
