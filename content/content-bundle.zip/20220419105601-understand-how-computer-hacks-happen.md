---
abbrlink: "20220419105601"
aliases: ["Understand how computer hacks happen"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:56:01
updated: 2022-05-26 16:33
title: Understand How Computer Hacks Happen
---

# Understand How Computer Hacks Happen

> [!tips]
>
> - Read news articles
> - Most big data breaches have several write ups that anyone can google and vegin to understand how these hacks happen
> - As you read more and more of these articles you will start to understand the common reasons why companies get hacked
> - Once you understand what the common themes are, you will be able to make recommendations based on what has happened to other companies
