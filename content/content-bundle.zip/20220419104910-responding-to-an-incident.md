---
abbrlink: "20220419104910"
aliases: ["Responding to an Incident"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:49:10
updated: 2022-05-26 16:33
title: Responding to an Incident
---

# Responding to an Incident

> [!word] Responding to an Incident
> How to respond to a [[20220419102338-security-incident|Security Incident]]

## Methods

1. [[20220419103415-nist-framework|NIST Framework]]
