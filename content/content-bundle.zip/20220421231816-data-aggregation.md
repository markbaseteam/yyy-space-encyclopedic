---
abbrlink: "20220421231816"
aliases: ["Data Aggregation"]
tags:
dg-publish: true
created: Thu 2022-04-21 23:18:16
updated: 2022-05-26 16:33
title: Data Aggregation
---

# Data Aggregation

> [!word] Data Aggregation
> Moving data coming from different sources into a common repository.
