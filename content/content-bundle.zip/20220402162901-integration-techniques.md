---
abbrlink: "20220402162901"
aliases: ["Integration Techniques"]
tags:
created: Sat 2022-04-02 16:29:01
updated: 2022-05-26 16:35
dg-publish: true
title: Integration Techniques
---

# Integration Techniques

## Thought Process When Solving Questions

1. Addition and subtraction Rules?
2. [[20220402164203-basic-indefinite-integrals|20220402164203 Basic Indefinite Integrals.md]]? <mark class="hltr-yellow">Basic Indefinite Integrals</mark>
   1. transform it into One?
3. A part which its derivative is in the formula? <mark class="hltr-yellow">Substitution</mark>
   1. Or can I find rearrange the formula to create one?
   2. Use double angle identities?
   3. Use long division?
4. By Parts?
