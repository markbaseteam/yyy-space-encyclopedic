---
title: Introduction to Cloud Computing
created: Sat 19-03-2022 10:50
updated: 2022-06-02 12:25
tags:
aliases:
  - Introduction to Cloud Computing
  - 20220319105026
dg-publish: true
---

# Introduction to Cloud Computing

> [!word] Cloud Computing
>
> Cloud computing is the **on-demand** delivery of compute power, database, storage, applications, and other IT resources **via the internet** with **[[20220520125934-pay-as-you-go|pay-as-you-go]]** pricing.
>
> Laymann Terms: Cloud Computing is using an **Internet-based server** instead of storing things on your own computer.

- [[20220318223248-cloud-computing|Cloud Computing]] enables you to **stop thinking of your infrastructure as hardware**, and instead **think of (and use) it as software**
