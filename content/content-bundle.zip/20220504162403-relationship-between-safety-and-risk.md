---
abbrlink: "20220504162403"
aliases: ["Relationship between Safety and Risk"]
dg-publish: true
created: 2022-05-04 16:24
updated: 2022-05-26 16:35
title: Relationship Between Safety and Risk
---

# Relationship Between Safety and Risk

> [!word] Relationship between Safety and Risk
> 安全是一个比较虚的概念：多安全才算安全？
>
> - [Risk](20220504160045-risk.md) 是量度 safety 的一个标准
>   - 质
>   - 量
