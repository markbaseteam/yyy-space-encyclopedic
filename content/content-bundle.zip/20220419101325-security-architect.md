---
abbrlink: "20220419101325"
aliases: ["Security Architect"]
tags:
dg-publish: true
created: Tue 2022-04-19 10:13:25
updated: 2022-05-26 16:33
title: Security Architect
---

# Security Architect

> [!word] Security Architect
>
> - Design computer IoT network
> - reduce the possibility of being the system being hacked by designing where to implement security controls
>   - How firewalls are to be placed
>   - where to store data backups
>   - how many separate networks are needed
> - Design Systems that are
>   - Secure
>   - fault tolerance
>   - redundant
> - So companies can provide their service or create their products with little or no interruptios
