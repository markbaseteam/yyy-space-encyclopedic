---
abbrlink: '20220606164855'
aliases: ["Removable media attack vectors"]
dg-publish: true
created: 2022-06-06 16:48
updated: 2022-06-06 16:53
title: Removable Media Attack Vectors
---

# Removable Media Attack Vectors

#attack-vectors 

- Get around the firewall 
	- Using a USB drive 
- [[20220602214144-malicious-flash-drive|Malicious Flash Drive]] 
	- Infect air gapped networks
		- Some part of the network isn't connected to the internet 
		- No direct communication to be able to communicate with it  
	- Industrial systems 
	- High-security services 
	- USB devices can act as keyboards 
		- "Hacker on a chip" 
			- The USB is just like a [[20220606153431-hacker|hacker]] living inside of the chip 
		- And start typing when you plug it in 
- Data exfiltration 
	- Data storage disks are getting larger and larger 
	- Terabytes of data walk out the door 
	- Zero bandwidths used 
