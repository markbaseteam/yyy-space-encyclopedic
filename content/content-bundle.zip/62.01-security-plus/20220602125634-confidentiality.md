---
abbrlink: '20220602125634'
aliases: ["Confidentiality", "机密性"]
dg-publish: true
created: 2022-06-02 12:56
updated: 2022-06-02 14:22
title: Confidentiality
tags: security+
---

# Confidentiality

>[!word] Confidentiality #security-basics
> Prevents the unauthorized disclosure of data.  
> 确保数据不会未经允许就被揭露。
> - 只是 authorized personnel 可以 access 哪些数据
<!--ID: 1654406588011-->


## 怎么确保机密性？

1. [[20220602130052-encryption|Encryption]] 
