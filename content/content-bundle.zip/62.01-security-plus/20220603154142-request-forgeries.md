---
abbrlink: '20220603154142'
aliases: ["Request Forgeries"]
dg-publish: true
created: 2022-06-03 15:41
updated: 2022-06-05 14:01
title: Request Forgeries
---

# Request Forgeries

1. [[20220605135019-server-side-request-forgery|Server-side Request Forgery]]
2. [[20220605133353-cross-site-request-forgery|Cross-site Request Forgeries]] 
