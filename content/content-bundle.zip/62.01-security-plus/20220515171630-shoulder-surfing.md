---
abbrlink: "20220515170344"
aliases: ["Dumpster diving"]
dg-publish: true
created: 2022-05-15 17:03
updated: 2022-05-31 17:29
title: Dumpster Diving
---

# Dumpster Diving

> [!word] Dumpster diving #attack
> 从垃圾桶中取得一些被扔掉的资料
> - 有很多重要资料
>   - 银行账单
> - 算好时间
>   - 每个月末 去检你那袋垃圾
<!--ID: 1653993498049-->


## Dumpster Diving 犯法吗？ #card

- 美国不犯法
  - 除非有特别的法律窥管
- 很多地方都是你不要了那谁想要就可以拿了
- 在私人地方的 dumpster 或者 "No Trespassing" 地带的地方就可能不可以
- May have gray areas
- 如果要翻垃圾桶，要和本地律师问清楚是否犯法

## Protecting Your Rubbish #card

- 保护你的垃圾
- 碎了你的文件
  - 政府通常会把重要文件給烧了
- 如果在公司
  - 可能放在一个有锁、有围栏的地带

## 名字来源

> [!tip]
> 美国一款垃圾桶的牌子叫 Dumpster
>
> - 大的那种从家里往外丢那种
> - ![[../60-Meta-Attachments/Pasted-image-20220515170617.png|Dumpster]]
