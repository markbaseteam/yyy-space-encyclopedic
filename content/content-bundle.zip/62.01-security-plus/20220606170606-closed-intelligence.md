---
abbrlink: '20220606170606'
aliases: ["Closed intelligence", "Proprietary Intelligence"]
dg-publish: true
created: 2022-06-06 17:06
updated: 2022-06-06 17:08
title: Closed Intelligence
---

# Closed Intelligence

>[!word] Closed intelligence
> These [[20220606165926-threat-intelligence|threat intelligence]] information are very valuable
> - Someone else has already compiled the threat information 
>     - you can buy it 
> - [[20220606165926-threat-intelligence|Threat intelligence]] services 
>     - Part of a business 
>     - threat analysis 
>     - correlation across different data sources 
> - Constant threat monitoring 
>     - Identify new threats 
>     - easy to use and analyze 
>     - create automated prevention workflows 
