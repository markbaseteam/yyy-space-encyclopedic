---
abbrlink: '20220606164610'
aliases: ["Social media attack vectors"]
dg-publish: true
created: 2022-06-06 16:46
updated: 2022-06-06 16:48
title: Social Media Attack Vectors
---

# Social Media Attack Vectors

#attack-vectors 
- Attackers thank you for putting your personal information online 
	- Where you are and when 
	- Vacation pictures are especially telling 
- User profiling 
	- Might be able to attack [[20220318214141-multi-factor-authentication|MFA]] 
	- Where were you born?
	- What is the name of your school mascot? 
- Fake friends are fake 
	- The inner circle can provide additional information 
