---
abbrlink: '20220603113827'
aliases: ["Non-persistent XSS attack", "Reflected XSS attack"]
dg-publish: true
created: 2022-06-03 11:38
updated: 2022-06-03 11:46
title: Non-persistent XSS Attack
---

# Non-persistent XSS Attack

>[!word] Non-persistent XSS attack
> Happens when website allows users to run scripts from user inputs, such as user input boxes. 
> - Attacker emails a link that takes advantage of this vulnerability
> - Script embedded in URL will run a script that sends credentials/ sessions IDs/ [[20220319074837-cookies|cookies]] to the attacker
>     - As if it came from the [[20220318223525-server|server]] 
> - Attacker uses credentials/session IDs/[[20220319074837-cookies|cookies]] to steal victim's information without their knowledge 
>     - very sneaky 
