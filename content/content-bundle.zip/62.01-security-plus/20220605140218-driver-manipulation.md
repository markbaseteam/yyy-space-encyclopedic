---
abbrlink: '20220605140218'
aliases: ["Driver Manipulation"]
dg-publish: true
created: 2022-06-05 14:02
updated: 2022-06-05 14:07
title: Driver Manipulation
---

# Driver Manipulation

>[!word] Driver Manipulation
> Making use of the OS's trust towards [[20220605140328-driver|drivers]] to attack, since hardware interactions contain sensitive information. 
> - Video, Keyboard, Mouse 

> [!example] Driver manipulation
> **HP Audio Drivers** - May 2016
> - Made use of **Conexant audioi chips** embedded in systems 
> - [[20220605140328-driver|Driver]] installation includes audio control software 
> - Debugging feature enables a keylogger
