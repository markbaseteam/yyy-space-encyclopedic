---
abbrlink: '20220621114421'
aliases: ["Compensating Controls"]
dg-publish: true
created: 2022-06-21 11:44
updated: 2022-06-21 11:44
title: Compensating Controls
---

# Compensating Controls

>[!word] Compensating Controls #control-type 
> Alternative Controls used when primary control is not feasible
