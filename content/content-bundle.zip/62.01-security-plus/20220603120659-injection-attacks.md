---
abbrlink: '20220603120659'
aliases: ["Injection Attacks"]
dg-publish: true
created: 2022-06-03 12:06
updated: 2022-06-03 13:05
title: Injection Attacks
---

# Injection Attacks

1. [[20220603120721-code-injection|Code injection]] 
2. [[20220603130513-sql-injection|SQL injection]] 
