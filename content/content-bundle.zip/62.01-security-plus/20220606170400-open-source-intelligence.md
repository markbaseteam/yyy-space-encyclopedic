---
abbrlink: '20220606170400'
aliases: ["Open-source intelligence", "OSINT"] 
dg-publish: true
created: 2022-06-06 17:04
updated: 2022-06-06 17:05
title: Open-source Intelligence
---

# Open-source Intelligence

> [!word] Open-source intelligence [OSINT] 
> - Open-source 
>     - Publicly available sources 
>     - A good place to start 
> - Internet 
>     - discussion groups 
>     - social media 
> - Government data 
>     - public hearings 
>     - reports 
>     - websites  
>     - etc.
> - Commercial data 
>     - Maps 
>     - financial reports 
>     - databases 
