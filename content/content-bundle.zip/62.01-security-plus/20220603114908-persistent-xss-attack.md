---
abbrlink: '20220603114908'
aliases: ["Persistent XSS attack", "Stored XSS attack"]
dg-publish: true
created: 2022-06-03 11:49
updated: 2022-06-03 11:57
title: Persistent XSS Attack
---

# Persistent XSS Attack

>[!word] Persistent XSS attack
>Anyone visiting the webiste will run that script.  
>- Attacker posts a message to a social network 
>     - which includes the malicious payload 
> - Then the malicious message is now hosted on the website 
> - Then the malicious message is now "persistent", and everyone gets the payload
> 
> Unlike [[20220603113827-non-persistent-xss-attack|Non-persistent XSS attack]], this does not have a specific target, so it targets all viewers to the page 
> - For social networking, this can spread quickly 
>     - everyone who likes/shares the message can have it posted to their page 
>         - where someone else can view it and propagate it further  

>[!example] Persistent XSS attack 
>June 2017, Aaron Guzman (security researcher)
>- When authenticating with Subaru, users get a token 
>    - but this token never expires (don't do this) 
>- A valid token allowed any service request 
>    - Even adding your email address to someone else's account 
>    - so now you have full access to someone else's car  
>The Subaru had a Persistent XSS vulnerability
