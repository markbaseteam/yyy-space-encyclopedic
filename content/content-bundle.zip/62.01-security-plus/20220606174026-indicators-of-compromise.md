---
abbrlink: '20220606174026'
aliases: ["Indicators of Compromise", "IOC"]
dg-publish: true
created: 2022-06-06 17:40
updated: 2022-06-06 17:43
title: Indicators of Compromise
---

# Indicators of Compromise

>[!word] Indicators of Compromise [IOC]
> - An event that indicates an intrusion 
>     - Confidence is high
>     - that someone is now in the network 
> - Indicators 
>     - Unusual amount of network activity 
>     - Sudden changes to file hash values 
>         - Files that originally shouldn't change 
>         - suddenly have a change in its hash value 
>     - Irregular international traffic 
>     - Changes to DNS Data 
>     - Uncommon login patterns 
>     - Spikes of read requests to certain files 
>     - and more 
