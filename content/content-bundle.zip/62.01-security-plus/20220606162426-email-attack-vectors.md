---
abbrlink: '20220606162426'
aliases: ["Email attack vectors"]
dg-publish: true
created: 2022-06-06 16:24
updated: 2022-06-06 16:29
title: Email Attack Vectors
---

# Email Attack Vectors

#attack-vectors 

- One of the biggest (and most successful) [[20220606160112-attack-vectors|attack vectors]] 
	- Everyone has email 
- [[20220513183720-phishing|Phishing]] attacks 
	- People want to click links 
- Deliver the [[20220516095203-malware|malware]] to the user 
	- Attach it to the message 
- [[20220515203457-social-engineering|Social engineering]] attacks 
	- [[20220515202117-invoice-scam|Invoice scam]] 
