---
abbrlink: '20220621114217'
aliases: ["Detective Controls"]
dg-publish: true
created: 2022-06-21 11:42
updated: 2022-06-21 11:42
title: Detective Controls
---

# Detective Controls

>[!word] Detective Controls
> Attempts to **detect incidents _after_ they have occured**
