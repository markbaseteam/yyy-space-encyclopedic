---
abbrlink: '20220606173628'
aliases: ["Trusted Automated Exchange of Indicator Information", "TAXII"]
dg-publish: true
created: 2022-06-06 17:36
updated: 2022-06-06 17:37
title: Trusted Automated Exchange of Indicator Information
---

# Trusted Automated Exchange of Indicator Information

>[!word] Trusted Automated Exchange of Indicator Information [TAXII] 
> The trusted method to securely share [[20220606173433-structured-threat-information-expression|STIX]] data
