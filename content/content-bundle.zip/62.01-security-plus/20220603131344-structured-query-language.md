---
abbrlink: '20220603131344'
aliases: ["Structured Query Language", "SQL"]
dg-publish: true
created: 2022-06-03 13:13
updated: 2022-06-03 13:14
title: Structured Query Language
---

# Structured Query Language

>[!word] Structured Query Language [SQL] #language 
> Commonly used to manage relational databases and perform various operations on the data in them. 
<!--ID: 1654406587884-->

