---
abbrlink: '20220621113740'
aliases: ["Operational Controls"]
dg-publish: true
created: 2022-06-21 11:37
updated: 2022-06-21 16:04
title: Operational Controls
---

# Operational Controls

> [!word] Operational Controls #control-category 
> > Implemented by people who perform day-to-day operations to comply with an organization's overall security plan.
> - day-to-day operations 
> - ensures that **day-to-day** operations comply with **security policy**
> - Primarility **implemented** and **executed** by people instead of systems

## Operational Control Families

1. [[#Awareness and Training 【意识培训】]]
1. [[#Configuration Management 【设置管理】]]
1. [[#Configuration Management 【初始设置及更改管理】]]
1. [[#Physical and Environmental Protection 【硬件及环境保护】]]

### Awareness and Training 【意识培训】

- Training to reduce risks 
- Benefits 
	- Maintain password security 
	- Follow a clean policy 
	- understand threats 

### Configuration Management 【初始设置及更改管理】

#### Configuration Management 【设置管理】

 Often uses **Baselines** to ensure that **systems start in a secure, hardened state** 
- 确保系统在开始时是属于安全状态的

#### Change Management 【更改管理】

Ensures that changes don't result in **unintended configuration errors** 

### Media Protection 【媒体保护】

*Media* refers to *Physical Media* in this case 

### Physical and Environmental Protection 【硬件及环境保护】

包含了：
- [[20220621114501-physical-controls|Physical Controls]] 
- Environmental Controls 
