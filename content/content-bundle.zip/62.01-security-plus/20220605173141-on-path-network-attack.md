---
abbrlink: '20220605173141'
aliases: ["On-path Network Attack", "On-path attack", "man-in-the-middle attack", "man-in-the-browser attack"]
dg-publish: true
created: 2022-06-05 17:31
updated: 2022-06-05 17:36
title: On-path Network Attack
---

# On-path Network Attack

>[!word] On-path Network Attack #attack 
> The attacker redirects your traffic, then passes it on to the destination. You never know your traffic was redirected.
<!--ID: 1654498554808-->

