---
abbrlink: '20220603094449'
aliases: ["Cloud-based attack"]
dg-publish: true
created: 2022-06-03 09:44
updated: 2022-06-03 09:53
title: Cloud-based Attack
---

# Cloud-based Attack

- Data is in a secure environment 
	- No physical access to the data center 
	- Third-party may have access to the data 
- Cloud providers are managing large-scale security 
	- automated signature and security updates 
	- Users must follow security best-practices 
- Limited downtime 
	- Extensive fault-tolerance 
	- 24/7 monitoring 
- Scalable security options 
	- One-click security deployments 
	- This may not be as customizable as necessary 
