---
abbrlink: '20220621114501'
aliases: ["Physical Controls"]
dg-publish: true
created: 2022-06-21 11:45
updated: 2022-06-21 11:45
title: Physical Controls
---

# Physical Controls

>[!word] Physical Controls #control-type 
> Controls you can **physically touch**
