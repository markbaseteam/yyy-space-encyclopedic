---
abbrlink: '20220605162930'
aliases: ["Wireless Jamming"]
dg-publish: true
created: 2022-06-05 16:29
updated: 2022-06-05 16:37
title: Wireless Jamming
---

# Wireless Jamming

Requires to be physically somewhere close for the jamming to be effectively 
- Attacker physically close 
- Attacker installs a device near that physical network 

## Types of Wireless Jamming

1. Send constant random amount of information over the network to overwhelm the good signal 
2. A constant amount of traffic, sending legitimate frames, and simply overwhelming the bandwidth 
3. The attacker intermittenly sending legitimately frames/ random data to distrupt the normal flow of communication 
4. Reactive Jamming 
	1. Only sending noisy data when someone else tries to communicate 
	2. Only finding one device, and limiting that device 

## Find the Source of Jamming

Finding the source of jamming may be #difficult 
- You may have to do a [[20220605163447-fox-hunt|Fox Hunt]] 
