---
abbrlink: '20220606161823'
aliases: ["Wireless attack vectors"]
dg-publish: true
created: 2022-06-06 16:18
updated: 2022-06-06 16:23
title: Wireless Attack Vectors
---

# Wireless Attack Vectors

#attack-vectors 
- Default login credentials 
	- Modify the access point configuration 
- [[20220605154002-rogue-access-points|Rogue Access Points]]
	- A less-secure entry point to the network 
	- Someone brings a wireless AP and plugs it in 
- [[20220605154444-wireless-evil-twin|Wireless Evil Twin]]
	- Attacker collects authentication details 
	- [[20220605173141-on-path-network-attack|On-path attack]]
- Protocol vulnerabilities 
	- 2017 - WPA2 Key Reinstallation Attack (KRACK)
	- Older encryption protocols 
		- WEP 
		- WPA
