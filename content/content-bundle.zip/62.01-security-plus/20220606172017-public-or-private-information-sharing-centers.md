---
abbrlink: '20220606172017'
aliases: ["Public or Private Information-sharing center", "Public information-sharing centers", "Private information-sharing centers"]
dg-publish: true
created: 2022-06-06 17:20
updated: 2022-06-06 17:22
title: Public or Private Information-sharing Centers
---

# Public or Private Information-sharing Centers

>[!word] Public or Private Information-sharing centers
> - Public [[20220606165926-threat-intelligence|threat intelligence]] 
>     - Often classified information 
>     - official by government 
> - Private [[20220606165926-threat-intelligence|threat intelligence]] 
>     - Private companies have extensive resources 
>     - often companies working in IT Security 
> - People need to share critial security details 
>     - real-time, high-quality cyber threat information sharing 
>     - [[20220606171859-cyber-threat-alliance|CTA]]
