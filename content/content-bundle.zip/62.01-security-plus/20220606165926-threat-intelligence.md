---
abbrlink: '20220606165926'
aliases: ["Threat intelligence"]
dg-publish: true
created: 2022-06-06 16:59
updated: 2022-06-06 17:03
title: Threat Intelligence
---

# Threat Intelligence

>[!word] Threat intelligence
> - Research the threats and the [[20220606150555-threat-actor|threat actors]] 
> - Data is everywhere 
>     - Hacker group profiles 
>     - tools used by the attackers 
>     - and much more 
> - Making decisions based on knowing those threat exist 
>     - Make decisions based on this intelligence 
>     - Invest in the best prevention 
> - Must always keep up to date with the latest threats 
> - Threat intelligence reports can be used by 
>     - Researchers 
>     - security operations teams 
>     - others 

## Sources of Threat Intelligence

- [[20220606170400-open-source-intelligence|OSINT]] 
- 