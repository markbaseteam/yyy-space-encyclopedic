---
abbrlink: '20220603094434'
aliases: ["On-premises attack"]
dg-publish: true
created: 2022-06-03 09:44
updated: 2022-06-03 09:51
title: On-premises Attack
---

# On-premises Attack

>[!word] On-premises attack
> 

- Customize your security posture 
	- full control whn everything is in-house 
- On-site IT team can manage security better 
	- The local team can ensure everything is secure 
	- But a local team can be expensive and difficult to staff 
- local team maintains uptime and availablility 
	- system checks can occur at any time 
	- No phone call for support 
- Security changes can take time 
	- New equipment 
	- configurations 
	- additional costs 
