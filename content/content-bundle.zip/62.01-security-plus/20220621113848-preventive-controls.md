---
abbrlink: '20220621113848'
aliases: ["Preventive Controls"]
dg-publish: true
created: 2022-06-21 11:38
updated: 2022-06-21 19:55
title: Preventive Controls
---

# Preventive Controls

> [!word] Preventive Controls #control-type
> > Primary Goal is to prevent security incidents 
>  
>Attempts to **prevent an incident from occuring**

## Examples of Preventive Controls

- Hardening 
- Training 
- Security Guards 
- Change Mangement 
- Account disablement policy 
- IPS
