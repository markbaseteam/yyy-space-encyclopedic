---
abbrlink: "20220515165116"
aliases: ["Credit Card Fraud"]
dg-publish: true
created: 2022-05-15 16:51
updated: 2022-05-31 18:38
title: Credit Card Fraud
---

# Credit Card Fraud

> [!word] Credit Card Fraud #fraud
> 用你的 姓名 等资料 开银行账户，或者 用你的 信用卡
<!--ID: 1653993498071-->

- 一种 [[20220515164936-identity-fraud|Identity Fraud]]
