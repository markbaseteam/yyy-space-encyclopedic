---
abbrlink: '20220606153914'
aliases: ["Semi-authorized hacker", "Grey hat hacker"]
dg-publish: true
created: 2022-06-06 15:39
updated: 2022-06-06 15:40
title: Semi-authorized Hacker
---

# Semi-authorized Hacker

>[!word] Semi-authorized hacker
> - finds a vulnerability 
> - doesn't use it or act on it 
> - more of a researcher 
> - trying to find access to a network 
> - without aiming to take advantage of the access
