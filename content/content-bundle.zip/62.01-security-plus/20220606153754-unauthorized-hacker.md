---
abbrlink: '20220606153754'
aliases: ["Unauthorized Hacker", "Black hat hacker"]
dg-publish: true
created: 2022-06-06 15:37
updated: 2022-06-06 15:38
title: Unauthorized Hacker
---

# Unauthorized Hacker

>[!word] Unauthorized Hacker
> - A malicious [[20220606153431-hacker|Hacker]] 
> - violates security for personal gain
