---
abbrlink: '20220602204704'
aliases: ["Dictionary attack"]
dg-publish: true
created: 2022-06-02 20:47
updated: 2022-06-02 20:53
title: Dictionary Attack
---

# Dictionary Attack

>[!word] Dictionary attack
> 用一本 dictionary 找 common words，因爲 passwords 是人設計的
> - 網上能找到很多字典，包括專業特定的，例如醫學字典
> - 而且工具可以 substitude 一些 letters 換成符號
>     - `password` -> `p&assw0rd`
> - 用很多時間，所以很多時候都是用 distributed cracking 或 GPU cracking 
