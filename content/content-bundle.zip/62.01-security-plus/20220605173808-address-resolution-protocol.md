---
abbrlink: '20220605173808'
aliases: ["Address-resolution Protocol", "ARP"]
dg-publish: true
created: 2022-06-05 17:38
updated: 2022-06-05 17:39
title: Address-resolution Protocol
---

# Address-resolution Protocol

>[!word] Address-resolution Protocol [ARP] #protocol 
> A protocol that connects an ever-changing IP address to a fixed physical address ([[20220605180300-media-access-control-address|MAC Address]]), in a LAN.  
<!--ID: 1654498554802-->

