---
abbrlink: "20220515164411"
aliases: ["Eliciting information"]
dg-publish: true
created: 2022-05-15 16:44
updated: 2022-05-31 17:28
title: Eliciting Information
---

# Eliciting Information

> [!word] Eliciting information #attack
> 发生在 [[20220515163456-impersonation|Impersonation]] 之后，从被骗者个人上抽取信息
>
> - Hacking the human
> - 被骗者不知道他们已经说出去了
> - 很容易取得 email 、[[20220319080333-passwords|密码]]、等 较难在非电话渠道中取到的咨询（因此普遍适用于 [[20220515152106-vishing|Vishing]] ）
<!--ID: 1653993498082-->


## Other Info

- 有很多已被记载的心理学方法让被骗者信任
- 并不会直接说 "So, what's your password? "
