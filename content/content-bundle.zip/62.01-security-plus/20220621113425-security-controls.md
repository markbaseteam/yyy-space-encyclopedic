---
abbrlink: '20220621113425'
aliases: ["Security Controls"]
dg-publish: true
created: 2022-06-21 11:34
updated: 2022-06-21 16:06
title: Security Controls
---

# Security Controls

## Control Categories

1. [[20220621113625-managerial-controls|Managerial Controls]] - 文件记录
2. [[20220621113740-operational-controls|Operational Controls]] - 日常操作规范
3. [[20220419111050-technical-controls|Technical Controls]] - 技术有关

## Control Types

- [[20220621113848-preventive-controls|Preventive Controls]] 
- [[20220621114217-detective-controls|Detective Controls]] 
- [[20220621114344-deterrent-controls|Deterrent Controls]] 
- [[20220621114421-compensating-controls|Compensating Controls]] 
- [[20220621114501-physical-controls|Physical Controls]] 
