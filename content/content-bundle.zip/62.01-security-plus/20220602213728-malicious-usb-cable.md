---
abbrlink: '20220602213728'
aliases: ["Malicious USB cable"]
dg-publish: true
created: 2022-06-02 21:37
updated: 2022-06-02 21:41
title: Malicious USB Cable
---

# Malicious USB Cable

>[!word] Malicious USB cable #physical-attack
> 想一個真的 充電線，但是裏面有 additional electronics 
> - 系統會 identity 它爲 HID [^1]
> - 就像你插入了 鍵盤 或 鼠標
>     - 然後他就可以想鍵盤一樣輸入任何他想輸入的東西
> - 但是鍵盤不會需要 extra rights or permissions 
> - 一鏈接，他就會開啓 命令行，然後開始下載 [[20220516095203-malware|malware]] 
<!--ID: 1654406587957-->


[^1]: Human Interface Device  
