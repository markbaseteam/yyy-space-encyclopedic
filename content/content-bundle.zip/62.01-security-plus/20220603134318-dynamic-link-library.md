---
abbrlink: '20220603134318'
aliases: ["Dynamic-Link Library", "DLL"]
dg-publish: true
created: 2022-06-03 13:43
updated: 2022-06-03 13:43
title: Dynamic-Link Library
---

# Dynamic-Link Library

>[!word] Dynamic-Link Library [DLL]
> - A windows library containing code and data 
> - many applications can use this library 
