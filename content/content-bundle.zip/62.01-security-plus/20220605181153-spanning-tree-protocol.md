---
abbrlink: '20220605181153'
aliases: ["Spanning Tree Protocol", "STP"]
dg-publish: true
created: 2022-06-05 18:11
updated: 2022-06-05 18:13
title: Spanning Tree Protocol
---

# Spanning Tree Protocol

>[!word] Spanning Tree Protocol [STP] #protocol 
> A network protocol that builts a loop-free logical topology for ethernet networks. 
> - Prevent bridge loops 
> - Prevent broadcast radiation 
> - Allows a network design to include backup links providing fault tolerance if an active link fails 
> 
<!--ID: 1654498554795-->

