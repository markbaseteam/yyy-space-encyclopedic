---
abbrlink: '20220605150929'
aliases: ["Memory Vulnerabilities"]
dg-publish: true
created: 2022-06-05 15:09
updated: 2022-06-05 15:17
title: Memory Vulnerabilities
---

# Memory Vulnerabilities

>[!word] Memory Vulnerabilities #vulnerability 
> Manipulating memory can be advantageous
> - Relatively #difficult to accomplish 
<!--ID: 1654498554833-->


## Cause of Memory Vulnerabilities

#cause 

### Memory Leak

A great choice for creating a [[20220606122813-denial-of-service|DoS]] 

- Unused memory is not properly released 
- Begins to slowly grow in size 
- Eventually uses all available memory 
- System crashes or Application failing 

### NULL Pointer Dereference

- When an attacker can make a program point to a NULL memory where nothing exists
- Then application crashes, debug information is displayed, and [[20220606122813-denial-of-service|DoS]]

### Integer Overflow

- When a large number is placed into a small section of memory 
	- The extra space has to go somewhere 
	- Which usually goes to the part of memory that is overflowed 
- You shouldn't be able to manipulate memory this way 
- #difficult to find 
	- in which this behaviour is repeatable
	- But if they do
		- can duplicate 
		- can manipulate in a way that is advantageous to them in controlling the system 
	- Then it is a very powerful attack 
