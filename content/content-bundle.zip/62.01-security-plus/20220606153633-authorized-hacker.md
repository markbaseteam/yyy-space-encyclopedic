---
abbrlink: '20220606153633'
aliases: ["Authorized Hacker", "Ethical Hacker", "White hat hacker"]
dg-publish: true
created: 2022-06-06 15:36
updated: 2022-06-06 15:37
title: Authorized Hacker
---

# Authorized Hacker

>[!word] Authorized Hacker
> - An ethical [[20220606153431-hacker|hacker]] with good intentions 
> -  And permission to hack 
> - helps find vulnerability 
> - and helps to fix them to make the system stronger 
> 
