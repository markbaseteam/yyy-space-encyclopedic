---
abbrlink: '20220606171859'
aliases: ["Cyber Threat Alliance", "CTA"]
dg-publish: true
created: 2022-06-06 17:18
updated: 2022-06-06 17:19
title: Cyber Threat Alliance
---

# Cyber Threat Alliance

>[!word] Cyber Threat Alliance
> - Members uplaod specifically formatted [[20220606165926-threat-intelligence|threat intelligence]] 
> - CTA Stores each submission and validates across other submissions 
> - Other members can extract the validated data 
