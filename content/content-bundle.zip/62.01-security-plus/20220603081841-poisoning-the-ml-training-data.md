---
abbrlink: '20220603081841'
aliases: ["Poisoning the ML training data"]
dg-publish: true
created: 2022-06-03 08:18
updated: 2022-06-03 08:22
title: Poisoning the ML Training Data
---

# Poisoning the ML Training Data

- Confuses the AI 
	- 攻擊者發送被 篡改 的數組給機器學習，就可以讓機器 behave incorectly 

> [!Example] Poisoning the ML Training data 
> Microsoft AI chatter bot named Tay (Thinking About You)
> - Joins Twitter on March 23, 2016
> - 設計者讓它去跟 Twitter 用戶溝通
> - 但設計者沒有設計到 anti-offensive behaviour 
> - Tay quickly became racist, sexist, and inappropriate 
