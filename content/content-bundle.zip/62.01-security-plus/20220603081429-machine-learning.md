---
abbrlink: '20220603081429'
aliases: ["Machine Learning"]
dg-publish: true
created: 2022-06-03 08:14
updated: 2022-06-03 08:31
title: Machine Learning
---

# Machine Learning

>[!word] Machine Learning #adversarial-AI
> 電腦自動尋找 patterns in data，並 improve their predictions 
> - 需要很多 data 
<!--ID: 1654406587926-->


## ML In Security

現在有用 machine learning 去幫助安全領域
1. stop [[20220515180310-spam|spam]] 
2. Recommend products from an online retailer 
3. I think you might wanna check out this movie…
4. Prevent car accidents 

>[!important] 
>- 機器學習算法設計者需要檢查訓練數據，保證數據的真實性和準確性
>- 最好每過一段時間就用更新更好的數據持續訓練
>- 最好也帶入攻擊者的角度，去訓練 AI 面對可能發生的 poisoning attack 
