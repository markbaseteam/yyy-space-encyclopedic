---
abbrlink: '20220621114344'
aliases: ["Deterrent Controls"]
dg-publish: true
created: 2022-06-21 11:43
updated: 2022-06-21 11:44
title: Deterrent Controls
---

# Deterrent Controls

>[!word] Deterrent Controls #control-type 
> Attempts to **discourage individuals** from **causing the incidient**
