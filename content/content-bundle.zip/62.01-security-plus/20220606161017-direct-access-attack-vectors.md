---
abbrlink: '20220606161017'
aliases: ["Direct access attack vectors"]
dg-publish: true
created: 2022-06-06 16:10
updated: 2022-06-06 16:14
title: Direct Access Attack Vectors
---

# Direct Access Attack Vectors

#attack-vectors
- There is a reason we lock the data center 
	- Physical access to a system is a significant attack vector 
- Modify the operating system 
	- Reset the administrator password in a few minutes 
- Attach a keylogger 
	- Collect usernames and [[20220319080333-passwords|passwords]] 
- Transfer files 
	- And take them with you 
- [[20220606122813-denial-of-service|DoS]] 
	- Well… This power cable is in the way 
