---
abbrlink: '20220621113625'
aliases: ["Managerial Controls"]
dg-publish: true
created: 2022-06-21 11:36
updated: 2022-06-21 15:45
title: Managerial Controls
---

# Managerial Controls

## Common Managerial Controls

- [[20220504182500-risk-assessment|Risk Assessments]] 
- [[20220621155010-vulnerability-assessment|Vulnerability Assessments]]
