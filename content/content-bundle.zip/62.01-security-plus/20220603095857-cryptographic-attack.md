---
abbrlink: '20220603095857'
aliases: ["Cryptographic Attack"]
dg-publish: true
created: 2022-06-03 09:58
updated: 2022-06-03 10:02
title: Cryptographic Attack
---

# Cryptographic Attack

- You've encrypted data and sent it to another person 
	- is it really secure?
	- How do you know? 
- The bad guy doesn't have the combination (the key) 
	- So they break the safe (the [[20220319080532-cryptography|cryptography]])
- Attackers use a lot of time finding ways to undo the security 
	- There are many potential cryptographic shortcomings 
	- The problem is often the implementation 
