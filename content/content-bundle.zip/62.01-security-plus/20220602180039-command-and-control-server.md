---
abbrlink: '20220602180039'
aliases: ["Command and Control Server", "C&C Server", "Command and Control", "C&C"]
dg-publish: true
created: 2022-06-02 18:00
updated: 2022-06-02 21:30
title: Command and Control Server
---

# Command and Control Server

>[!word] Command and Control Server [C&C Server]
> 控制 [[20220602172655-bots|bots]] 和 [[20220602175910-botnet|botnet]]
