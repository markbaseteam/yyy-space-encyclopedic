---
abbrlink: '20220605152826'
aliases: ["Improper Input Handling"]
dg-publish: true
created: 2022-06-05 15:28
updated: 2022-06-05 15:30
title: Improper Input Handling
---

# Improper Input Handling

> **All input should be considered malicious.** Check Everything. Trust nobody. 

- Allowing invalid input can be devastating 
	- [[20220603130513-sql-injection|SQL injection]] 
	- [[20220603135105-buffer-overflow|Buffer Overflow]] 
	- [[20220606122813-denial-of-service|DoS]] 
	- etc.

> [!note] Improper Input Handling 
> It takes a lot of work to find input that can be used maliciously, but they will eventually find it 
