---
abbrlink: '20220602184432'
aliases: ["Plaintext or Unencrypted Passwords"]
dg-publish: true
created: 2022-06-02 18:44
updated: 2022-06-02 18:46
title: Plaintext or Unencrypted Passwords
---

# Plaintext or Unencrypted Passwords

>[!word] Plaintext or Unencrypted Passwords
> 有些软件没有加密就储存[[20220319080333-passwords|密码]]，虽然很少见，但是如果你用的软件是这样储存[[20220319080333-passwords|密码]]的，就立刻抛弃它。
