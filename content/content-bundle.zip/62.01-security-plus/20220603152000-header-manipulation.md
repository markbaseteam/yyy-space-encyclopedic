---
abbrlink: '20220603152000'
aliases: ["Header Manipulation"]
dg-publish: true
created: 2022-06-03 15:20
updated: 2022-06-03 15:23
title: Header Manipulation
---

# Header Manipulation

>[!word] Header Manipulation
> Collect information about a user session 
> 1. Information gathering 
>     1. directly from the internet 
>         1. Wireshark 
>         2. Kismet 
>     2. Exploit 
>         1. [[20220603113047-cross-site-scripting|XSS]] vulnerability  
> 2. Modify 
>     1. headers 
>         1. Tamper 
>         2. Firesheep 
>         3. Scapy 
>     2. [[20220319074837-cookies|Cookies]] 
>         1. [[20220319074837-cookies|Cookies]] Manager+ (Firefox add-on)
