---
abbrlink: '20220606165401'
aliases: ["Cloud attack vectors"]
dg-publish: true
created: 2022-06-06 16:54
updated: 2022-06-06 16:58
title: Cloud Attack Vectors
---

# Cloud Attack Vectors

#attack-vectors 

- Most cloud applications are publicly-facing 
	- The configuration of the application and the application itself must be secure 
		- Such as data permissions and public data stores 
- [[20220602203501-brute-force-attck|Brute force]] attacks or [[20220513183720-phishing|phish]] the users of the cloud service 
- Make you waste resources using Orchestration attacks 
	- Increase the load on a specific cloud-based service 
		- By requiring additional instances of the application to be created 
