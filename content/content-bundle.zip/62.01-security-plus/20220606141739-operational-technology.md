---
abbrlink: '20220606141739'
aliases: ["Operational Technology", "OT"]
dg-publish: true
created: 2022-06-06 14:17
updated: 2022-06-06 14:21
title: Operational Technology
---

# Operational Technology

> [!word] Operational Technology [OT]
> The hardware and software for industrial equipment 
> - eletric grids 
> - traffic control 
> - Manufacturing plants 
> - etc.
