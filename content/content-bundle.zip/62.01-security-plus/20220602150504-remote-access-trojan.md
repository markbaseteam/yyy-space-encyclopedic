---
abbrlink: '20220602150504'
aliases: ["Remote Access Trojan", "RAT", "RATs", "Remote Administration Tool", "远程控制牧马程式", "远程访问木马"]
dg-publish: true
created: 2022-06-02 15:05
updated: 2022-06-02 15:15
title: Remote Access Trojan
---

# Remote Access Trojan

>[!word] Remote Access Trojan [RAT] #attack 
>让 第三者 有基本上 完全 的 远程控制 
> - 通常 [[20220602145709-backdoor|后门]] 会安装
> - "The Ultimate [[20220602145709-backdoor|Backdoor]]"
<!--ID: 1654406587991-->


- How to prevent? -> [[20220602143703-trojan#Preventing Trojans]]

>[!note] RAT 控制系统方式
>1. Key logging 
>    1. [[20220319080333-passwords|密码]]
>2. Screen recording/ screenshots
>3. Copy files 
>    1. 从你电脑
>    2. 到你电脑
>4. Embed more [[20220516095203-malware|malware]] 

>[!example] RAT 
> ![DarkComet RAT](https://raw.githubusercontent.com/SheepYY039/PicGo-images/main/img/20220602151240.png?token=ANN6KINFO73HOSRTHAOSSJLCTBRSK)
