---
abbrlink: '20220606171007'
aliases: ["Common Vulnerabilities and Exposures", "CVE"]
dg-publish: true
created: 2022-06-06 17:10
updated: 2022-06-06 17:16
title: Common Vulnerabilities and Exposures
---

# Common Vulnerabilities and Exposures

#database 
>[!word] Common Vulnerabilities and Exposures
> - A community managed list of vulnerabilities 
> - Sponsored by the U.S. DHS[^1] and CISA[^2]
> - Can be found on the U.S. National Vulnerability Database (NVD)
>     - A summary of CVEs 
> - NVD Provides additional details over the CVE list 
>     - Patch availability
>     - Severity scoring 
> 
> [NVD - Home](https://nvd.nist.gov/)

[^1]: U.S. Department of Homland Security
[^2]: Cybersecurity and infrastructure security agency 
