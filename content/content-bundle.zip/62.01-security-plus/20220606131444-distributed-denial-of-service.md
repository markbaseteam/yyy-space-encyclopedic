---
abbrlink: '20220606131444'
aliases: ["Distributed Denial of Service", "DDoS"]
dg-publish: true
created: 2022-06-06 13:14
updated: 2022-06-06 13:17
title: Distributed Denial of Service
---

# Distributed Denial of Service

>[!word] Distributed Denial of Service [DDoS] #attack 
> - Launch an army of computers to bring down a service 
>     - use all the bandwidth or resource 
>     - cause a traffic spike 
> - A [[20220602175910-botnet|Botnet]] is often used to create DDoS 
>     - Thousands or millions of computers are at your command 
> - The attacker may have fewer resources than the victim
>     - but using a [[20220602175910-botnet|botnet]], the resources can easily overwhelm the victim 
<!--ID: 1654498554782-->


>[!example] DDoS 
>At its peak, the **Zeus [[20220602175910-botnet|botnet]]** infected over 3.6 million PCs 
