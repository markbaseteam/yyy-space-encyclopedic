---
abbrlink: '20220606174348'
aliases: ["Predictive analysis"]
dg-publish: true
created: 2022-06-06 17:43
updated: 2022-06-06 20:22
title: Predictive Analysis
---

# Predictive Analysis

>[!word] Predictive analysis
> Try to predict what attackers are trying to do, or where are they trying to focus on. 
> - Analyze large amounts of data very quickly 
>     - Find suspicous patterns 
>     - Big data used for cybersecurity 
> 
