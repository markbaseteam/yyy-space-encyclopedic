---
abbrlink: '20220603101024'
aliases: ["Downgrade attack"]
dg-publish: true
created: 2022-06-03 10:10
updated: 2022-06-03 10:13
title: Downgrade Attack
---

# Downgrade Attack

>[!word] Downgrade attack #attack
> Instead of using perfectly good [[20220602130052-encryption|encryption]], use something that's not so great, to force the systems to downgrade their security. 
<!--ID: 1654406587918-->


>[!example] Downgrade attack 
>2014 - [[20220605142819-secure-sockets-layer|TLS]] Vulnerability POODLE [^1] 
>- [[20220605173141-on-path-network-attack|On-path attack]] 
>- Forces clients to fallback to [[20220605142819-secure-sockets-layer|SSL]] 3.0 
>- [[20220605142819-secure-sockets-layer|SSL]] 3.0 has significant cryptographic vulnerabilities 
>- Because of POODLE, modern broswers won't fallback to [[20220605142819-secure-sockets-layer|SSL]] 3.0

[^1]: Padding Oracle On Downgraded Legacy [[20220602130052-encryption|Encryption]] 
