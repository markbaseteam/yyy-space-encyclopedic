---
abbrlink: '20220603112648'
aliases: ["Data Execution Prevention"]
dg-publish: true
created: 2022-06-03 11:26
updated: 2022-06-03 11:27
title: Data Execution Prevention
---

# Data Execution Prevention

>[!word] Data Execution Prevention
> Only allow data to run in certain areas of memory 
