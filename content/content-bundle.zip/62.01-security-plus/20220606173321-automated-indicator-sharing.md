---
abbrlink: '20220606173321'
aliases: ["Automated Indicator Sharing", "AIS"]
dg-publish: true
created: 2022-06-06 17:33
updated: 2022-06-06 17:36
title: Automated Indicator Sharing
---

# Automated Indicator Sharing

>[!word] Automated Indicator Sharing [AIS] 
> - Intelligence industry needs a 
>     - standard way to share important threat data 
>         - [[20220606173433-structured-threat-information-expression|STIX]] 
>     - ability to share information freely and safe  
>         - [[20220606173628-trusted-automated-exchange-of-indicator-information|TAXII]] 
