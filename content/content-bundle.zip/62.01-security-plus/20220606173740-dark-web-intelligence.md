---
abbrlink: '20220606173740'
aliases: ["Dark web intelligence"]
dg-publish: true
created: 2022-06-06 17:37
updated: 2022-06-06 17:40
title: Dark Web Intelligence
---

# Dark Web Intelligence

>[!word] Dark web intelligence
> - Useful information to gather from the [[20220606173748-dark-web|dark web]] 
>     - Hacking groups and services 
>         - Activities 
>         - tools and techniques 
>         - credit card sales
>         - accounts and [[20220319080333-passwords|passwords]] 
> - Communcation methods 
>     - Monitor forums for activity 
>         - Company names 
>         - executive names 
