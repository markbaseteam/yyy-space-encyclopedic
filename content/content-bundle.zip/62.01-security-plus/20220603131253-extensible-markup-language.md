---
abbrlink: '20220603131253'
aliases: ["Extensible Markup Language", "XML"]
dg-publish: true
created: 2022-06-03 13:12
updated: 2022-06-03 13:13
title: Extensible Markup Language
---

# Extensible Markup Language

>[!word] Extensible Markup Language [XML] #language
>  A set of rules for data transfer and storage 
<!--ID: 1654406587890-->

