---
abbrlink: '20220606141705'
aliases: ["Operational Technology DoS", "OT DoS", "OT DDoS"]
dg-publish: true
created: 2022-06-06 14:17
updated: 2022-06-06 14:23
title: Operational Technology DoS
---

# Operational Technology DoS

> [!word] Operational Technology DoS [OT DoS] 
> The impact is more than just a web server failing 
> - Power grid drops offline 
> - All traffic lights are green 
> - Manufacturing plant shuts down 
> 
> Requires a totally different approach to tackle 
> - cannot only put a firewall in place and believe that you have all the security in place 
