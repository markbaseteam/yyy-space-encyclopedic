---
abbrlink: '20220606173433'
aliases: ["Structured Threat Information Expression", "STIX"]
dg-publish: true
created: 2022-06-06 17:34
updated: 2022-06-06 17:35
title: Structured Threat Information Expression
---

# Structured Threat Information Expression

>[!word] Structured Threat Information Expression [STIX] 
> A standardized format to 
> - describe cyber threat information 
> - includes 
>     - motivations 
>     - abilities 
>     - capabilities
>     - response information 
