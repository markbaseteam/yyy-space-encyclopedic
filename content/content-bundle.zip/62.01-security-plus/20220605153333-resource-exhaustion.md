---
abbrlink: '20220605153333'
aliases: ["Resource Exhaustion"]
dg-publish: true
created: 2022-06-05 15:33
updated: 2022-06-06 14:11
title: Resource Exhaustion
---

# Resource Exhaustion

>[!word] Resource Exhaustion
> A specialized [[20220606122813-denial-of-service|DoS]] attack, may only require **one device** and **low bandwidths** 


> [!example] Resource Exhaustion 
> **DHCP Starvation**
> - Attacker floods a network with IP Address requests 
> - [[20220605180300-media-access-control-address|MAC Address]] changes each time 
> - DHCP server eventually runs out of addresses 
> 
> Switch configurations can rate limit DHCP requests 
