---
abbrlink: '20220605162031'
aliases: ["Radio Frequency Jamming", "RF Jamming"]
dg-publish: true
created: 2022-06-05 16:20
updated: 2022-06-05 16:29
title: Radio Frequency Jamming
---

# Radio Frequency Jamming

>[!word] Radio Frequency Jamming #wireless-jamming
> Allows the attacker to distrupt the network and create a [[20220606122813-denial-of-service|DoS]] 
> 
> - Happens when [[20220605162251-signal-to-noise-ratio|signal-to-noise ratio]] at the receiving device is **decreased**
> - Sometimes not intentional (Interference instead of Jamming)  
>     - Maybe someone turned on the Microwave oven, and interference is causing the signals to not be received by the end-stations 
> - Jamming is intentional 
>     - Attacker sends noise to the network 
>     - Attacker does not want your network to work 
>     - So someone else cannot receive that wireless signal 
<!--ID: 1654498554821-->

