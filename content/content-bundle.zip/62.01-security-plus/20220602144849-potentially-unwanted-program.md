---
abbrlink: '20220602144849'
aliases: ["Potentially Unwanted Program", "PUP", "潜在有害程序"]
dg-publish: true
created: 2022-06-02 14:48
updated: 2022-06-02 14:55
title: Potentially Unwanted Program
---

# Potentially Unwanted Program

>[!word] Potentially Unwanted Program
> 不一定是 [[20220516095203-malware|malware]]，也不一定会伤害你的电脑，但大多会下载你不想要的程序，影响电脑 performance 

>[!example] PUP 
>![在一部被严重感染的Windows机里被发现的PUP](https://raw.githubusercontent.com/SheepYY039/PicGo-images/main/img/20220602145513.png?token=ANN6KIPQ4R5XA5APHIE2KGLCTBPQ4)
>1. Overly aggressive broswer toolbar 
>    - 很烦
>    - 很难删除
>2. 一个不停出广告的备份软件
>3. Browser search engine hijacker 
>    - 你每次搜东西他就会 redirect 你去另一个搜索软件
