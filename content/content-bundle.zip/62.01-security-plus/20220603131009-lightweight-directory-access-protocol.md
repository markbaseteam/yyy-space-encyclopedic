---
abbrlink: '20220603131009'
aliases: ["Lightweight Directory Access Protocol", "LDAP"]
dg-publish: true
created: 2022-06-03 13:10
updated: 2022-06-03 13:11
title: Lightweight Directory Access Protocol
---

# Lightweight Directory Access Protocol

>[!word] Lightweight Directory Access Protocol [LDAP] #protocol
> - A protocol created by the telephone companies
> - Now used by almost everyone 
<!--ID: 1654406587897-->

