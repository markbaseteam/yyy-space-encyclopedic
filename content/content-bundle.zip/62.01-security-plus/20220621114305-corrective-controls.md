---
abbrlink: '20220621114305'
aliases: ["Corrective Controls"]
dg-publish: true
created: 2022-06-21 11:43
updated: 2022-06-21 11:43
title: Corrective Controls
---

# Corrective Controls

>[!word] Corrective Controls #control-type 
> Attempts to **reverse the impact** of an incident
