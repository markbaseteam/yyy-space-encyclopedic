---
abbrlink: '20220603094128'
aliases: ["Supply Chain Security"]
dg-publish: true
created: 2022-06-03 09:41
updated: 2022-06-03 09:43
title: Supply Chain Security
---

# Supply Chain Security

Because of [[20220603085818-supply-chain-attack|Supply Chain Attack]]

#trust 

- Can you trust your new [[20220318223525-server|server]]/ router/ switch/ firewall/ software?
- More and more companies are using a smaller supplier base to have a tighter control of vendors
	- more testing and more auditing 
- Strict controls over policies and procedures 
	- Ensure proper security is in place 
- Security should be part of the overall design 
