---
title: Traditional Vs Cloud Systems
created: Fri 18-03-2022 22:49
updated: 2022-05-26 16:35
tags:
aliases:
  - Traditional vs Cloud Systems
abbrlink: "20220318224932"
dg-publish: true
---

# Traditional Vs Cloud Systems

Difference between [[20220319105139-traditional-computing-model|Traditional Computing Model]] and [[20220319105437-cloud-computing-model|Cloud Computing Model]]

|             | Traditional                                                                      | Cloud                                                    |
| ----------- | -------------------------------------------------------------------------------- | -------------------------------------------------------- |
| Location    | located in one physical space                                                    | accessible from any physical space through the internet. |
| System Size | fixed to the amount purchased with the system                                    | adjustable based on the user’s needs                     |
| Portability | not portable; fixed in place                                                     | portable; can be accessed anywhere with any device       |
| User load   | can handle only as may users as the device processor speed and memory can handle | can handle many users with ease.                         |
