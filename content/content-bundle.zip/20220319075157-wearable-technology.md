---
title: Wearable Technology
created: Sat 19-03-2022 07:51
updated: 2022-05-31 18:24
tags:
aliases: [Wearable Technology]
abbrlink: "20220319075157"
dg-publish: true
---

# Wearable Technology

## Privacy

Wearable fitness trackers and smart watch devices often are enabled with GPS, which can identify a person’s location.
