---
abbrlink: "20220430151953"
aliases: ["Manjaro File Hierarchy"]
tags:
dg-publish: true
created: Sat 2022-04-30 15:19:53
updated: 2022-05-26 16:35
title: Manjaro File Hierarchy
---

# Manjaro File Hierarchy

- `/etc/`
  - `lightdm/`
	- `lightdm.conf`
	  - Greeter setup [Install Display Managers - Manjaro](https://wiki.manjaro.org/index.php/Install_Display_Managers)
	  - Login Customisation
  - `pacman.conf`
	- Setup `pacman`
	- uncomment `Color` for `yay` and `pacman` color
