---
abbrlink: "20220419122243"
aliases: ["User Access Control"]
tags:
dg-publish: true
created: Tue 2022-04-19 12:22:43
updated: 2022-05-31 16:10
title: User Access Control
---

# User Access Control

> [!word] User Access Control
> Controlling what information users have edit access to. To limit the potential for users to edit information without permission.

> [!question]
> What is the relationship between this and [[20220318212854-least-privilege|Least Privilege]]?
