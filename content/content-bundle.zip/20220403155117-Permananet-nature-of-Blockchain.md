---
abbrlink: "20220403155117"
aliases: ["Permananet nature of Blockchain"]
created: Sun 2022-04-03 15:51:17
updated: 2022-05-26 16:41
dg-publish: true
title: Permananet Nature of Blockchain
---

# Permananet Nature of Blockchain

## The Ideal Case for Blockchain

This only exist conceptually as of now.

1. When a [[20220327121426 Smart Contract.md|Smart Contract]] gets deployed, then anyone can run the code forever
2. If the [[20220331193235 Cryptocurrency.md|Cryptocurrency]] creation company goes bankcrupt, it currency can still be used
3. Totally [[20220331193536 Decentralize.md|Decentralized]]

## Why is it Difficult to Alter?

1. (2015 - 2022) The [[20220327120946 Ethereum.md|Ethereum]] network already has [[20220403155640 Size of a chain.md|500G data]], very difficult to alter
   1. 時間越長，越難更改，因為數據會越多
